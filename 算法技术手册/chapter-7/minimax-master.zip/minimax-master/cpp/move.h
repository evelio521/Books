class Move {
	public:
	bool switchesActivePlayer() {return true;}
	int usedDepth() {return 1;}
};
