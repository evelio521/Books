data Stone = Blue | Red

data VierGewinnt = VierGewinnt 
