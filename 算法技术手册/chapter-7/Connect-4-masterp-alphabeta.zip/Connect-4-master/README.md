# Connect 4
A CLI implementation of the Connect 4 game

## Getting Started
### Installation
```bash
    make && make install
```

## Author
[Fadi Hanna Al-Kass](http://fadialkass.blogspot.com)
