
#ifndef __ConnectGame__ConnectBoard__
#define __ConnectGame__ConnectBoard__


//
// @File Name: ConnectBoard.h
// @Author: Fadi Hanna Al-Kass, W001FHE
//

#include "AlphaBeta.h"


typedef Board::player   Player;
typedef Board::boards   Boards;

#define BoardPointer    Board *
#define BoardReference  Board &
#define ConstBoardPointer   const BoardPointer
#define ConstBoardReference const BoardReference


#define ConstBoardsReference const BoardsReference

#define ConnectBoardPointer ConnectBoard *
#define ConnectBoardReference   ConnectBoard &
#define ConstConnectBoardPointer const ConnectBoardPointer
#define ConstConnectBoardRefrence const ConnectBoardReference


#define Position        ConnectBoard::position
#define WinPattern      ConnectBoard::winPattern
#define ConstWinPattern const WinPattern


using std::string;  // needed for maxName() & miniName()


/* This is an encapsulation for the Connec4 game board. */
class ConnectBoard : public Board
{
public:

   static const int WIDTH = 7;                  /* Number of columns in the board */
   static const int HEIGHT = 6;                 /* number of elements in each column */
   static const int WINNING_PATTERN_LEN = 4;    /* This is the number of elements in one line in order to win */
   static const int NUM_WINNING_PATTERNS = 4;   /* The number of winning patterns */
   

   /* Position holder */
   struct position
   {
      int x;
      int y;

      /* Constructor; x and y initializer */
      position(int x, int y)
      {
          this->x = x;
          this->y = y;
      }
   };


   /*
    *   @Brief: Default constructor
    *   @Precondition: None
    *   @Postcondition: None
    *   Note: Invoke this constructor to initialize an instance
    *   of the board to contain @Board::None at all @(position)s
    */
   ConnectBoard();


   /*
    *   @Brief: copy instructor
    *   @Precondition: None
    *   @Postcondition: Initialize a copy of the original board
    *
    *   Note: The initialized board will contain tokens in all
    *   positions to make with the original tokens.
    */
   ConnectBoard(ConstConnectBoardRefrence);


   /*
    * @Brief: virtual destructor
    * @Precondition: None
    * @Postcondition: Free up all memory used by all data structures
    *  in the class
    */
   virtual ~ConnectBoard();
   

   /*
    * @Brief:   Get a list of all legal moves on the board
    * @Precondition:    None
    * @Postcondition:   None
    */
   virtual ConstBoardsReference getAvailableMoves(Player);
   

   /*
    * @Brief: Returns either @Board::MAX, @Board::MIN, or @Board::NONE
    * @Precondition:    None
    * @Postcondition:   Return MAX, MIN, or NONE based on the indicated
    *                   winner value.
   */
   virtual Player winner();


   /*
    * @Brief:           Return the score indicated by the current game board set-up.
    * @Precondition:    None
    * @Postcondition:   Returns a positive score if the board favors the @Black player,
    *                   negative score if the board favors the @Red player,
    *                   and zero if neither of the players is favored.
   */
   virtual int getScore();


   /*
    * @Brief: Returns name of the max (maximum) player
    * @Precondition: None
    * @Postcondition: None
    */
   virtual string getMaxName() const
   {
      return "Black";
   }
   

   /*
    * @Brief:           Returns name of the min (minimum) player
    * @Precondition:    None
    * @Postcondition:   None
    */
   virtual string getMinName() const
   {
       return "Red";
   }
   
private:
   typedef position winPattern[WINNING_PATTERN_LEN];            /* winning patterns holder */
   static const winPattern winPatterns[NUM_WINNING_PATTERNS];   /* constant winning patterns holder */
   Player positions[WIDTH][HEIGHT];                            /* Player tokens holder */
   Boards *successors;                                          /* will be used to hold the result of @getAvailableMoves */
   int score;                                                   /* Will be used to hold the moce recent score
                                                                   calculated by @getScore() */
   bool hasScored;                                              /* will be set to true if the board has been scored, false
                                                                   otherwise */

public:
   static size_t max_num_instance;      /* will be used to keep track of the number of instances created */
   static size_t cur_num_instance;      /* Will be used to keep track of the current instances created */
   static size_t mun_reused_instance;   /* Will be used to keep track of the number of reused instances */


   /*
    *   @Brief:         Equality comparison
    *   @Precondition:  None
    *   @Postcondition: None
   */
   bool operator ==(ConstConnectBoardRefrence);


   /*
    *   @Brief:         Returns a string representation of the game board
    *   @Precondition:  None
    *   @Postcondition: None
    */
   operator string () const;
   

   /*
    *   @Brief: Returns false if the specified column is already full or doesn't exist.
    *           Returns true otherwise.
    *   @Precondition:  None
    *   @Postcondition: None
   */
   bool dropAt(Player, int);
   

   /*
    *   @Brief: Returns false if the specified column is already full or doesn't exist.
    *           Returns true otherwise.
    *   @Precondition:  None
    *   @Postcondition: None
   */
   Board::player occupyAt(Position position) const
   {
      if (position.x >= 0 && position.x < WIDTH)
          if (position.y >= 0 && position.y < HEIGHT)
              return positions[position.x][position.y];

      return NONE;  // false
   }
   

   /*
    *   @Brief:         Sets the player token at the specified position
    *                   on the board
    *   @Precondition:  Specified position must be within the board.
    *   @Postcondition: The board will NOT be modified if the specified
    *                   position is NOT within the board.
   */
   void setOccupantAt(Player, Position);

   /*
    *   @Brief:         Returns a calculated score based on the specified pattern
    *                   and a starting position within the board.
    *   @Precondition:  None
    *   @postcondition: None
   */
   int getPatternScoreAt(ConstWinPattern, int, int) const;

};

#endif /* defined(__ConnectGame__ConnectBoard__) */
