//
// @File name: AlphaBeta.cpp
// @Author: Fadi Hanna Al-Kass, W001FHE
//

#include "AlphaBeta.h"
#include <cassert>

typedef Board::player Player;
typedef Board::boards Boards;

#define None    Board::NONE
#define Max     Board::MAX
#define Min     Board::MIN

#define BoardPointer Board *
#define BoardReference Board &


int Board::makeAutomaticPlayerMove(Player player, BoardPointer & resultingBoard)
{
   return alphaBeta(player, resultingBoard);
}


int Board::alphaBeta(Player player, BoardPointer & nextBoardPtr, int depth, int alpha, int beta)
{
   nextBoardPtr = NULL;
   
   boards availableMoves = getAvailableMoves(player);
   
   if(winner() != NONE) /* someone has won  */
      return getScore();

   else if((getDepthPerformance() <= depth) || (availableMoves.size() == 0))    /* search limit reached or no legal moves */
      return getScore();
   else
   {
      Boards::iterator it(availableMoves.begin());
      
      if(player == Max)
      {
         while(it != availableMoves.end() && alpha < beta)
         {
            BoardPointer candidateBoardPtr = NULL;
            
            /* Get the highest score maximizer can hope to get after playing at column *it */
            int newAlpha = (*it)->alphaBeta(Min, candidateBoardPtr, depth + 1, alpha, beta);
            
            if(newAlpha > alpha)
            {
               alpha = newAlpha;
               nextBoardPtr = (*it);
               assert(NULL != nextBoardPtr);
            } // EOF if
            
            ++it;
         } // EOF while
         
         return alpha;
      } // EOF if


      else  /* Minimizing player */
      {
          while(it != availableMoves.end() && alpha < beta)
         {
            Board *candidateBoardPtr = NULL;
            
            /* Get the lowest score minimizer can hope to get after playing at column *it */
            int newBeta = (*it)->alphaBeta(Max, candidateBoardPtr, depth + 1, alpha, beta);

            if(newBeta < beta)
            {
               beta = newBeta;
               nextBoardPtr = (*it);
               assert(NULL != nextBoardPtr);
            }   // EOF if
            
            ++it;
         }  // EOF while
         
         return beta;
      } // EOF inner else
   } // EOF outer else
} // EOF alphaBeta()
