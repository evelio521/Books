//
// @File Name: ConnectBoard.cpp
// @Author: Fadi Hanna Al-Kass, W001FHE
//

#include "ConnectFour.h"
#include <cstdlib>
#include <sstream>
#include <cassert>
#include <cstring>




size_t ConnectBoard::max_num_instance =    0x00;
size_t ConnectBoard::cur_num_instance =    0x00;
size_t ConnectBoard::mun_reused_instance = 0x00;

//#define BoardsReference Board::boards &
#define Position ConnectBoard::position
#define Boards  Board::boards


using std::endl;
using std::max;
using std::stringstream;


/*
 *  @Brief:         Constructor-- initializes the board instance to be open at all positions
 *  @Precondition:  None
 *  @Postcondition: None
*/
ConnectBoard::ConnectBoard()
{
    score = 0x00;
    hasScored = false;
   successors = new Board::boards; /* Open up all psitions */
   
   for(int i = 0; i < ConnectBoard::WIDTH; i++)
      for(int j = 0; j < ConnectBoard::HEIGHT; j++)
          setOccupantAt(Board::NONE, position(i, j));
   
   cur_num_instance++;
   max_num_instance = max(cur_num_instance, max_num_instance);
}

/*
 * @Brief:          Constructor-- initializes the board as a copy of the original.
 * @Precondition:   None
 * @Postcondition:  The newly initialized board contains tokens
 *                  in every position to match the tokens in original.
*/
ConnectBoard::ConnectBoard(const ConnectBoard &original)
{
    score = 0x00;
    hasScored = false;

    /* copy every position from original */
   successors = new Board::boards;
   
   memcpy(positions, original.positions, sizeof(positions));
   
   cur_num_instance++;
   max_num_instance = max(cur_num_instance, max_num_instance);
}


/*
 *  Destructor
*/
ConnectBoard::~ConnectBoard()
{
   Board::boards::iterator it(successors->begin());
   while(it != successors->end())
   {
      delete (*it);
      ++it;
   }
   
   delete successors;
   successors = NULL;
   cur_num_instance--;
}


/*
 *   @Brief:         Equality comparison
 *   @Precondition:  None
 *   @Postcondition: None
*/
bool ConnectBoard::operator ==(const ConnectBoard &other)
{
   for(int i = 0; i < WIDTH; i++)
   {
      for(int j = 0; j < HEIGHT; j++)
      {
         Position position(i, j);
         
         if (occupyAt(position) != other.occupyAt(position))
            return false;
      } // EOF for
   } // EOF outer for
   
   return true;
}


/*
 * @Brief:   Get a list of all legal moves on the board
 * @Precondition:    None
 * @Postcondition:   None
 */
const Board::boards & ConnectBoard::getAvailableMoves(Player player)
{
   if(successors->size() == 0)
   {
      for(int i = 0; i < WIDTH; i++)
      {
         if(positions[i][HEIGHT - 1] == NONE)           /* At least one position is available in column */
         {
            ConnectBoardPointer newBoard = new ConnectBoard(*this);
            bool status = newBoard->dropAt(player, i);
            assert(status);
            successors->insert(newBoard);
         } // EOF if
      } // EOF for
   } // EOF if

   else
      mun_reused_instance++;
   
   return *successors;
}


/*
 *  @Brief:         returns a calculated score based on the
 *                  specified pattern and a starting position
 *                  within the board.
 *  @Precondition:  This function must be called for each possible
 *                  x and y position, and each possible winning
 *                  pattern to verify a winning path by any of the
 *                  two players.
 *  @Postcondition: None
*/
int ConnectBoard::getPatternScoreAt(const winPattern aPattern, int x, int y) const
{
   int result = 0;
   for(int i = 0; i < WINNING_PATTERN_LEN; i++)
   {
      position position(x + aPattern[i].x, y + aPattern[i].y);
         
      result += occupyAt(position);
   }
   
   return result;
}


/*
 *  @Brief:         Returns an identifier for the player who wins
 *  @Precondition:
 *  @Postcondition: Return Max if the mazimizer player wins,
 *                  Min if the minimizer player wins
 *                  None if no winner has been found
*/
Player ConnectBoard::winner()

{
   Player result = NONE;
   
   int currentScore = getScore();
   
   if(currentScore == getMaxWinningScore())
      result = MAX;

   else if(currentScore == getMinWinningScore())
      result = MIN;
    
   return result;
}


/*
 * @Brief:           Return the score indicated by the current game board set-up.
 * @Precondition:    None
 * @Postcondition:   Returns a positive score if the board favors the @Black player,
 *                   negative score if the board favors the @Red player,
 *                   and zero if neither of the players is favored.
*/
int ConnectBoard::getScore()
{
   if(!hasScored)
   {
      {  /* Pattern 0: a vertical win */
         const int applicableHeight = HEIGHT - (WINNING_PATTERN_LEN - 1);
         
         for(int i = 0; i < WIDTH; i++)
         {
            for(int j = 0; j < applicableHeight; j++)
            {
               int candidateScore = this->getPatternScoreAt(winPatterns[0], i, j);
                                    
               if(abs(candidateScore) > abs(score))
               {
                  score = candidateScore;
                  
                  if(score >= WINNING_PATTERN_LEN)              /* maximizer won */
                  {
                     hasScored = true;
                     score = getMaxWinningScore();
                     return score;                              /* bail out of nested loops */
                  } // EOF of
                  else if(score <= (-WINNING_PATTERN_LEN))  /* minimizer player has won */
                  {
                     hasScored = true;
                     score = getMinWinningScore();
                     return score;                              /* bail out of nested loops */
                  } // EOF else if
               } // EOF outer if
            } // EOF for
         } // EOF outer for
      } // EOF pattern 0


      {  // Pattern 1: a horizontal win
         const int applicableWidth = ConnectBoard::WIDTH - (ConnectBoard::WINNING_PATTERN_LEN - 1);
         
         for(int i = 0; i < applicableWidth; i++)
         {
            for(int j = 0; j < HEIGHT; j++)
            {
               int candidateScore = this->getPatternScoreAt(winPatterns[1], i, j);
                                    
               if(abs(candidateScore) > abs(score))
               {
                  score = candidateScore;
                  
                  if(score >= WINNING_PATTERN_LEN)
                  {                                 /* maximizer won */
                     hasScored = true;
                     score = getMaxWinningScore();
                     return score;                  /* bail out of nested loops */
                  } // EOF if
                  else if(score <= -WINNING_PATTERN_LEN)
                  {                                 /* minimizer won */
                     hasScored = true;
                     score = getMinWinningScore();
                     return score;                  /* bail out of nested loops */
                  } // EOF else if
               } // EOF if
            } // EOF for
         } // EOF outer for
      } // EOF pattern 1


      {  /* Pattern 2: a diagonal win */
         const int applicableWidth = WIDTH - (WINNING_PATTERN_LEN - 1);
         const int applicableHeight = HEIGHT - (WINNING_PATTERN_LEN - 1);
         
         for(int i = 0; i < applicableWidth; i++)
         {
            for(int j = 0; j < applicableHeight; j++)
            {
               int candidateScore = getPatternScoreAt(winPatterns[2], i, j);
                                    
               if(abs(candidateScore) > abs(score))
               {
                  score = candidateScore;
                  
                  if(score >= WINNING_PATTERN_LEN)
                  {  /* maximizer won */
                     hasScored = true;
                     score = getMaxWinningScore();
                     return score;  /* bail out of nested loops */
                  } // EOF if
                  else if(score <= -WINNING_PATTERN_LEN)
                  {  /* minimizer won */
                     hasScored = true;
                     score = getMinWinningScore();
                     return score;  /* bail out of nested loops */
                  } /* EOF else if */
               } // EOF if
            } // EOF for
         } // EOF outer for
      } // EOF pattern 2


      {  /* Pattern 3 is diagonal win */
         const int applicableWidth = WIDTH - (WINNING_PATTERN_LEN - 1);
         const int applicableHeight = HEIGHT - (WINNING_PATTERN_LEN - 1);
         
         for(int i = 0; i < applicableWidth; i++)
         {
            for(int j = 0; j < applicableHeight; j++)
            {
               int candidateScore = getPatternScoreAt(winPatterns[3], i, j);
                                    
               if(abs(candidateScore) > abs(score))
               {
                  score = candidateScore;
                  
                  if(score >= WINNING_PATTERN_LEN)
                  {  /* maximizer won */
                     hasScored = true;
                     score = getMaxWinningScore();
                     return score;  /* bail out of nested loops */
                  } // EOF if
                  else if(score <= -WINNING_PATTERN_LEN)
                  {  /* minimizer won */
                     hasScored = true;
                     score = getMinWinningScore();
                     return score;  /* bail out of nested loops */
                  } // EOF else if
               } // EOF if
            } // FOR
         } // ROF outer for
      } // EOF pattern 3
      hasScored = true;
   }    // EOF outer if
   
   return score;
}


/*
 *  @Brief:         Return true if the drop process succeedes,
 *                  and false otherwise.
 *  @Precondition:  Column lables are identified by values 0, 1, 2
 *                  and so on.
 *  @Postcondition: Return false if the specified column does NOT
 *                  exist or exists but is full.
*/
bool ConnectBoard::dropAt(Player player, int column)
{
   bool result = false;
   
   for(int j = 0; !result && j < HEIGHT; j++)
   {
      position position(column, j);
      
      if(NONE == occupyAt(position))
      {  /* Attempt to set the token in the lowest open
            position within the specified column */
         setOccupantAt(player, position);
         
         /* Verify the block was added to the board */
         result = (player == occupyAt(position));
      } // EOF if
   } // EOF for
   
   return result;
} // EOF dropAt



/*
 *  @Brief:         sets the player token at the specified
 *                  position within the board.
 *  @Precondition:  If the specified position is invalid, the
 *                  board will NOT be modified.
 *  @Postcondition: None
*/
void ConnectBoard::setOccupantAt(Player player, Position position)
{
   if(position.x >= 0 &&  position.x < WIDTH)
       if (position.y >= 0 && position.y < HEIGHT)  /* Position is within the board */
           positions[position.x][position.y] = player;
}


/*
 *   @Brief:         Returns a string representation of the game board
 *   @Precondition:  None
 *   @Postcondition: None
 */
ConnectBoard::operator string () const
{
   stringstream sstream;
   sstream << endl;
   
   // Print column labels
   for(int i = 0; i < WIDTH; i++)
   {
      char label = 'A' + i;
      sstream << "  " << label << ' ';
   } // EOF for

   sstream << "\n";
   
   // Print play area
   for(int j = HEIGHT-1; j >= 0; j--)
   {
      for(int i = 0; i < WIDTH; i++)
         sstream << "----";

      sstream << "-\n";

      for(int i = 0; i < WIDTH; i++)
      {
          Position position(i, j);
         
         if(NONE == occupyAt(position))
             sstream << "|   ";

         else if(MIN == occupyAt(position))
             sstream << "| O ";

         else
             sstream << "| X ";

      } // EOF for

      sstream << "|\n";

   } // EOF outer for
   
   /* Print bottom edge of play area */
   for(int i = 0; i < WIDTH; i++)
      sstream << "----";

   sstream << "-\n";

   /* Report number of boards currently considered  out of total boards ever considered */
   sstream << cur_num_instance << " / " << max_num_instance << " (" << mun_reused_instance << ")" <<  endl;
   
   return sstream.str();
}


/*
 *  @Brief:         This array stores all the valid winning patterns for player tokens.
 *  @Precondition:  None
 *  @Postcondition: None
*/
const ConnectBoard::winPattern ConnectBoard::winPatterns[WINNING_PATTERN_LEN] =
{
   { position(0,0), position(0,1), position(0,2), position(0,3)}, /* Vertical pattern */
   { position(0,0), position(1,0), position(2,0), position(3,0)}, /* Horizontal pattern */
   { position(0,0), position(1,1), position(2,2), position(3,3)}, /* Diagonal pattern A */
   { position(0,3), position(1,2), position(2,1), position(3,0)}  /* Diagonal pattern B */
};
