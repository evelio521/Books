//
// @File name: AlphaBeta.h
// @Author: Fadi Hanna Al-Kass, W001FHE
//


#ifndef __ConnectGame__AlphaBeta__
#define __ConnectGame__AlphaBeta__

#include <set>
#include <string>
#include <iostream> 
#include <climits>


#define BoardPointer            Board *
#define BoardReference          Board &
#define BoardPointerSet         set<BoardPointer>

#define BoardsPointer           boards *
#define BoardsReference         boards &
#define ConstBoardsPointer      const BoardPointer
#define ConstBoardsReference    const BoardsReference

using std::set;
using std::string;
using std::ostream;


/*
 *  This is an interface encapsulating the Connec4 2-player board game
*/
class Board
{
public:


   /*
    *   This is the player identifier.
   */
   typedef enum
   {
      MAX = 1,
      NONE = 0,
      MIN = -1
   }
   player;
   

   typedef BoardPointerSet boards;
   
   /*
    * @Brief: virtual destructor
    * @Precondition:  None
    * @Postcondition: None
   */
   virtual ~Board()
   {
        // Intentionally Left Empty
   }


   /*
    *   @Brief:         Return the set of all boards resulting from the current
    *                   board set-up upon making a move by the specified player.
    *   @Precondition:  The move selected by the alpha-beta function will produce
    *                   one of the boards in the set returned.
    *   @Postcondition: None
   */
   virtual ConstBoardsReference getAvailableMoves(player) = 0;
   

   /*
    *   @Brief:         *. If the current board indicates that the
    *                   maximizer has won, return MAX.
    *                   *. If the minimizer has won, return MIN
    *                   returns Minimizer.
    *                   *. Returns NONE if neither the maximizer
    *                   not the minimizer has won.
    *   @Precondition:  None
    *   @Postcondition: None
   */
   virtual player winner() = 0;
   

   /*
    *   @Brief:         Return the score indicated by the current board set-up.
    *   @Precondition:  *. If the board favors the MAX player, the return value
    *                   should be positive.
    *                   *. If the board favors the MIN player, the return value
    *                   should be negative.
    *                   *. If neither of the players is favored, the return value
    *                   should be zero.
    *   @Postcondition: None
*/
   virtual int getScore() = 0;


    /*
     *  @Brief:         Return the name of the MAX player
     *  @Precondition:  None
     *  @Postcondition: None
    */
   virtual string getMaxName() const = 0;


    /*
     *  @Brief:         Return the name of the MIN player
     *  @Precondition:  None
     *  @Postcondition: None
    */
   virtual string getMinName() const = 0;


    /*
     * @Brief:          Return a string representation of the board
     * @Precondition:   None
     * @Postcondition:  None
    */
   virtual operator string () const = 0;


    /*
     * @Brief:          returns a reasonable default search depth
     *                  for the alpha-beta function to use with
     *                  most board games.
     * @Precondition:   None
     * @Postcondition:  None
    */
   virtual int getDepthPerformance() const
   {
      return 9; /* The heigher the number, the more time
                it'll take the computer to think the next move */
   }
   

    /*
     * @Brief:          Returns the score that indicates the MAX player has won.
     * @Precondition:   Return value must be greater than 0 and less than INT_MAX
     * @Postcondition:  Return a reasonable default for board games
    */
   virtual int getMaxWinningScore() const
   {
      return INT_MAX - 1;
   }


    /*
     * @Brief:          Return the score that indicates the MIN player has won.
     * @Precondition:   Return value must be less than zero and greater than -INT_MAX
     * @Postcondition:  Return a reasonable default for board games
    */
   virtual int getMinWinningScore() const
   {
      return -INT_MAX + 1;
   }


    /*
     * @Brief:          Returns a pointer to the board set-up resulting from the move
     * @Precondition:   This function lets the alpha-beta function select
     *                   the best move for the specified player.
     * @Postcondition:  None
    */
   int makeAutomaticPlayerMove(player, BoardPointer &);


   /*
    * @Brief:           Outputs the string representation of the
    *                   board to the specified stream.
    * @Precondition:    None
    * @Postcondition:   None
   */
   void print(ostream &stream)
   {
      string output(*this);
      stream << output;
   }

   
private:

   /*
    * @Brief:           Implements the alpha-beta pruning algorithm
    *                   to build and evaluate a tree of possible board
    *                   configurations resulting from player moves as players
    *                   alternate turns.
    * @Precondition:    None
    * @Postcondition:   None
   */
   int alphaBeta(player, BoardPointer &, int depth = 0, int alpha = -1 * INT_MAX, int beta = INT_MAX);
};


#endif /* defined(__ConnectGame__AlphaBeta__) */
