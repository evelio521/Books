
#include "ConnectFour.h"
#include <assert.h>
#include <iostream>
#include <limits>
#include <cstdlib>

//
// @File Name: main.cpp
// @Author: Fadi Hanna Al-Kass, W001FHE
//


#define MAX_NUMERIC_SIZE    numeric_limits<streamsize>::max()

#define BoardPointer Board *
#define BoardReference Board &
#define ConstBoardPointer const BoardPointer
#define ConstBoardReference const BoardReference

//#define BoardsPointer Boards *
//#define BoardsReference Boards &
//#define ConstBoardsPointer const BoardsPointer
#define ConstBoardsReference const BoardsReference

#define None Board::NONE
#define Max  Board::MAX
#define Min  Board::MIN

typedef Board::boards boards;
typedef Board::boards Boards;
typedef Board::player Player;
typedef std::string string;



using std::cin;
using std::cout;
using std::endl;
using std::numeric_limits;
using std::streamsize;





static BoardPointer autoMove(Player currentPlayer, BoardPointer curGameBoard, string playerName, string prediction)
{
   assert(NULL != curGameBoard);

   cout << endl << playerName << " Player's Turn";
   cout.flush();

   BoardPointer nextBoard = NULL;
   int score = curGameBoard->makeAutomaticPlayerMove(currentPlayer, nextBoard);
   curGameBoard = dynamic_cast<ConnectBoardPointer>(nextBoard);

   assert(curGameBoard != NULL);  /* crash the program if a new board has not been assigned */

   if(score == 0)
       cout << prediction;   /* print out Tie prediction */

   return curGameBoard;
}


static BoardPointer userMove(Player curPlayer, BoardPointer curGameBoard, string playerName, ConstBoardsReference successors)
{
   cout << playerName << " Your turn. Specify a column [A-G]: ";
   char selected_cal_label = 'A';

   ConnectBoardPointer boardToCopy = dynamic_cast<ConnectBoardPointer>(curGameBoard);
   ConnectBoard newBoard(*boardToCopy);

   do
   {
      cin.clear();                  /* Clear buffer */
      cin >> selected_cal_label;    /* Read input from keyboard */

      cin.ignore(MAX_NUMERIC_SIZE, '\n');  /* Anything characters typed to end of
                                                               the line are automatically ignored*/
      selected_cal_label = toupper(selected_cal_label);
   }

   while(!newBoard.dropAt(curPlayer,selected_cal_label - 'A')); // while input is invalid

   bool found = false;

   Boards::iterator it(successors.begin());
   while(it != successors.end() && !found)
   {
      ConnectBoardPointer candidatePtr = dynamic_cast<ConnectBoardPointer>(*it);

      if(*candidatePtr == newBoard)
      {
         found = true;
         curGameBoard = candidatePtr;
      }

      ++it;
   }

   return curGameBoard;
}


/*
 * @Brief:  1. Display an empty game board.
 *          2. Read column number as a user input from the keyboard
 *          3. Apply all moves
 *          4. Disply winner name if one of the two players has won.
 *             display "Tie" otherwise.
 * @Precondition:   None
 * @Postcondition:  None
*/
int main(int argc, const char *argv[])
{

    ConnectBoard initBoard;

    Board *curBoard = &initBoard;
    int numPlayers = 1;

    if(argc > 1)    /* if a program argument is sent */
       numPlayers = atoi(argv[1]);  /*Note: atoi parses a string into an integer value */

    curBoard->print(cout);  /* Print out the newly initiated board (should have all empty slots */

    Player curPlayer = Max;  /* Let the 'Black' player go first  */

    /* Retrieve all unoccupied columns on the board */
    boards successors(curBoard->getAvailableMoves(curPlayer));

    /* while neither of the players has won and there's at least one unoccupied slot on the board */
    while((successors.size() > 0) && (curBoard->winner() == None))
    {
       if(curPlayer == Max)  /* curPlayer is black? */
       {
          if(numPlayers == 0)
             curBoard = autoMove(curPlayer, curBoard, curBoard->getMaxName(), "Tie is predicted");

          else
             curBoard = userMove(curPlayer, curBoard, curBoard->getMaxName(), successors);

          curPlayer = Min;   /* red player's turn */
       }    // EOF if

       else
       {
          if(numPlayers < 2)
              curBoard = autoMove(curPlayer, curBoard, curBoard->getMinName(), "Tie is predicted");

          else
             curBoard = userMove(curPlayer, curBoard, curBoard->getMinName(), successors);

          curPlayer = Max;
       }    // EOF else

       curBoard->print(cout);   /* Print game board with all the occupied locations on it */

       successors = curBoard->getAvailableMoves(curPlayer); /* get an updated list of the remaining legal moves */
    }   // EOF while

    if(curBoard->winner() == None)
       cout << "It's a Tie" << endl;

    else if(curBoard->winner() == Max)
       cout << endl << curBoard->getMaxName() << " is the winner" << endl;

    else
        cout << endl << curBoard->getMinName() << " is the winner" << endl;

    return EXIT_SUCCESS;
}   // EOF main
