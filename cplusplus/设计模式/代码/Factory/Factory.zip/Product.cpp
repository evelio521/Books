#include "Product.h"
#include <iostream>
using namespace std;

Product::~Product()
{
}
Product::Product()

{
}

ConcreteProduct::ConcreteProduct(){
	cout<<"ConcreteProduct...."<<endl;
}
ConcreteProduct::~ConcreteProduct()
{


}

ConcreteProduct2::ConcreteProduct2(){
	cout<<"ConcreteProduct2...."<<endl;
}
ConcreteProduct2::~ConcreteProduct2()
{


}